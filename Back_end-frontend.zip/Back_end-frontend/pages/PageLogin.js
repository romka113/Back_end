import { PageTemplate } from "../lib/PageTemplate.js";

class PageLogin extends PageTemplate {
  mainHTML() {
    return `LOGIN PAGE CONTENT`;
  }
}

export { PageLogin };
