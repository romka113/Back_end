import { PageTemplate } from "../lib/PageTemplate.js";

class PageHome extends PageTemplate {
  mainHTML() {
    return `HOME PAGE CONTENT`;
  }
}

export { PageHome };
