import { PageTemplate } from "../lib/PageTemplate.js";

class PageRegister extends PageTemplate {
  mainHTML() {
    return `REGISTER PAGE CONTENT`;
  }
}

export { PageRegister };
